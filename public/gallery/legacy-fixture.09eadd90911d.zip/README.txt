Synthetic gallery delivery fixture. No customer photographs.
